// Shared storage for the price list (Netlify Blobs).
// GET  /api/store            -> saved state (public)
// GET  /api/store?img=<key>  -> saved photo (public)
// POST /api/store            -> save state   (admin password required)
// POST /api/store?img=<key>  -> save photo   (admin password required)
import { getStore } from "@netlify/blobs";

const SALT = "gearup-dist:";
// SHA-256 of SALT + admin password (same password as the page). Override with the ADMIN_HASH env var.
const DEFAULT_HASH = "03fa47b55cfd44155740affed227deb556223d35983e95d028b1b26930ced4a8";
const MAX_STATE = 4 * 1024 * 1024, MAX_IMG = 4 * 1024 * 1024;

const store = () => getStore({ name: "solar-price-list", consistency: "strong" });
const env = (k) => (globalThis.Netlify?.env?.get?.(k)) ?? process.env[k];

async function sha256(s) {
  const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, "0")).join("");
}
const authed = async (req) =>
  (await sha256(SALT + (req.headers.get("x-admin-pw") || ""))) === (env("ADMIN_HASH") || DEFAULT_HASH);
const json = (o, status = 200) =>
  new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });

export default async (req) => {
  const url = new URL(req.url);
  const img = url.searchParams.get("img");
  if (img !== null && !/^[\w.-]{1,200}$/.test(img)) return json({ error: "bad key" }, 400);
  try {
    if (req.method === "GET") {
      if (img) {
        const buf = await store().get("img:" + img, { type: "arrayBuffer" });
        if (!buf) return new Response("Not found", { status: 404 });
        return new Response(buf, { headers: { "content-type": "image/jpeg", "cache-control": "public, max-age=31536000, immutable" } });
      }
      return json((await store().get("state", { type: "json" })) || {});
    }
    if (req.method === "POST" || req.method === "DELETE") {
      if (!(await authed(req))) return json({ error: "unauthorized" }, 401);
      if (req.method === "DELETE") {
        if (img) await store().delete("img:" + img);
        return json({ ok: true });
      }
      const body = await req.arrayBuffer();
      if (img) {
        if (body.byteLength > MAX_IMG) return json({ error: "image too large" }, 413);
        await store().set("img:" + img, body);
        return json({ ok: true });
      }
      if (body.byteLength > MAX_STATE) return json({ error: "data too large" }, 413);
      const state = JSON.parse(new TextDecoder().decode(body));
      if (!state || typeof state !== "object" || Array.isArray(state)) return json({ error: "bad data" }, 400);
      await store().setJSON("state", state);
      return json({ ok: true });
    }
    return json({ error: "method not allowed" }, 405);
  } catch (e) {
    return json({ error: "server error" }, 500);
  }
};

export const config = { path: "/api/store" };
