Deploy on Netlify (needed for online saving of products/photos/prices)
1. Put this folder in a GitHub repository.
2. Netlify -> Add new site -> Import from Git -> pick the repo. Build settings are read from netlify.toml. Deploy.
3. Open https://YOUR-SITE.netlify.app , click Admin login, edit. Changes now save online for all visitors.
Optional: to change the admin password, set the ADMIN_HASH environment variable in Netlify to
SHA-256 of  gearup-dist:<newpassword>  AND replace H1 in public/index.html with the same value.
Uploading only public/index.html (drag-and-drop) still works as a plain page, but edits then stay in the admin's browser.
